<?php

require_once('init.php');
//$value=0;
$value = mysql_result(mysql_query("SELECT currentVal FROM usageDetails") or die(mysql_error()),0);


  $response["currentValue"] = $value;
  $response["lastMonth"] = "0.00";

echo json_encode($response);
$conn->close();


?>