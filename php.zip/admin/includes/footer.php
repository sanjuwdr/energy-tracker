</div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    
	<script>
		jQuery(document).ready(function() {
		  jQuery("time.timeago").timeago();
		});
		</script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/jquery.timeago.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="js/metisMenu/metisMenu.min.js"></script>

   
   

    <!-- Custom Theme JavaScript -->
    <script src="js/sb-admin-2.js"></script>
    <script src="js/jquery.validate.min.js"></script>

</body>

</html>