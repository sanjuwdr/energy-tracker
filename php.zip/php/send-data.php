<?php
include 'init.php';

$sql = "SELECT * FROM usageDetails";
$result = $conn->query($sql);

$rows = array();
while($r = mysqli_fetch_assoc($result)) {
    $rows[] = $r;
}
$data = array('energy' => $rows);
print json_encode($data);
 
$conn->close();
?>