<?php

require_once('init.php');
$usage = ($_GET["currentValue"]);

date_default_timezone_set('Asia/Kolkata'); 
$dt= date("d"); // time in India

if ($usage){

$sql = "UPDATE usageDetails SET currentVal='$usage'";//, now())”;

	if($dt==01)//do every month
	{
		$res="UPDATE usageDetails SET currentVal=0,lastMonth='$usage'";
		$conn->query($res);
	}	
	
if ($conn->query($sql) === TRUE) {
echo "Record updated successfully";
	
} else {
echo "Error updating record:" . $conn->error;
}

$conn->close();

}

?>