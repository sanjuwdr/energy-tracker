<?php

$servername = "localhost";
$username = "onegroup_tracker";
$password = "spnsre123";
$dbname = "onegroup_energy";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

?>