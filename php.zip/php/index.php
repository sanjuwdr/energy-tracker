{
"energy": [
{
"currentUsage": "50",
"lastMonth": "30.0",
"email": "user@gmail.com"
}
]
}
